import json
from os import path
import funciones as fn

dicProfs = {}
ruta = "resultados/rankingProf.txt"

if path.exists(ruta):
    archPunt = open(ruta, "r", encoding="UTF-8")
    archPunt = archPunt.readline()
    dicProfs = dict(json.loads(archPunt))
else:
    dicTPuntero = open("resultados/comentariosAnalizadosTT.txt", "r", encoding='UTF-8')
    dicTexto = dicTPuntero.readline()
    # dicTextoPlano = dicTexto.replace("'", "\"")
    dicPC = dict(json.loads(dicTexto))
    print(len(dicPC.keys()))
    fn.rankingProf(dicPC, dicProfs)

    archPerfiles = open("resultados/rankingProf.txt", "w", encoding="UTF-8")
    archPerfiles.write(json.dumps(dicProfs))

#print(dicProfs["ROCÍO ELIZABETH MERA SUÁREZ"])

top = 100
listaT = ["joy", "fear", "anger", "confident", "analytical", "tentative"]
fn.presentRanking(listaT, top, dicProfs)